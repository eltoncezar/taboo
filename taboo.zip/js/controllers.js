'use strict';

/* Controllers */

var tabooControllers = angular.module('tabooControllers', []);

tabooControllers.controller('menuCtrl', ['$scope', '$http',
    function($scope, $http) {
        $scope.startGame = function () {
            window.location.href = '#/game';
        };
    }
]);

tabooControllers.controller('gameCtrl', ['$scope', '$timeout', '$http',
    function ($scope, $timeout, $http) {
        $scope.points = 0;
        $scope.teams = new Array();
        $scope.usedWords = new Array();

        $http.get('js/words.json').success(function(data) {
            $scope.words = data;
            $scope.startGame(2, 30);
        });


        $scope.startGame = function (teams, duration) {
            startTimer(duration);
            $scope.selectedWord = getRandomWord();
        }

        function getRandomWord() {
            var random;
            do {
                random = getRandomInt(0, $scope.words.length - 1);
            }
            while ($scope.usedWords.contains(random))

            $scope.usedWords.push(random);

            if ($scope.usedWords.length === $scope.words.length) {
                $scope.usedWords.length = 0;
                $scope.usedWords.push(random);
            };

            return $scope.words[random];
        }

        $scope.nextWord = function () {
            $scope.selectedWord = getRandomWord();
            $scope.points++;
        }

        $scope.skipWord = function () {
            $scope.selectedWord = getRandomWord();
        }

        $scope.back = function () {
            window.location.href = '#/phones?time=time1&points=' + $scope.points;
        }

        function startTimer(time) {
            $scope.count = time;

            $scope.onTimeout = function(){
            $scope.count--;
            if ($scope.count > 0) {
                mytimeout = $timeout($scope.onTimeout, 1000);
            }
            else {
                    //window.location.href = '../taboo/endGame.html?time=time1&points=10';
                }
            }
            var mytimeout = $timeout($scope.onTimeout, 1000);
        }




    }
]);

tabooControllers.controller('endGameCtrl', ['$scope', '$routeParams',
    function($scope, $routeParams) {
        //$scope.phoneId = $routeParams.phoneId;
    }
]);



// Returns a random integer between min and max
// Using Math.round() will give you a non-uniform distribution!
function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1) + min);
}

Array.prototype.contains = function(obj) {
        for(var i = 0; i < this.length; i++) {
            if(this[i] === obj) {
                return 1;
            }
        }
        return 0;
    };